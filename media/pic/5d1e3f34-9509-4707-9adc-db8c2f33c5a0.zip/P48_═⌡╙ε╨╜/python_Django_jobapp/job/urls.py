from django.conf.urls import url
from . import views
# 为了跨域重定向使用
app_name='job'
#user 子路由
urlpatterns = [
    url(r'^$',views.jobtype,name='jobtype'),

]
