from django.http import HttpResponse
from django.utils.deprecation import MiddlewareMixin
class AuthMiddleWare(MiddlewareMixin):
    def process_request(self, request):
        print(request.GET.get('id'))
        print('333')
        # return HttpResponse('sorry')

    def process_view(self, request, callback, callback_args, callback_kwargs):
        i = 1
        print('444')
        pass

    def process_exception(self, request, exception):
        print('555')
        return HttpResponse(exception)

    def process_response(self, request, response):
        print('666')
        return response