from django.shortcuts import render

from django.http import  HttpResponse,response
from django.http import JsonResponse

from  datetime import datetime,timedelta
# Create your views here.
def personal(request):
    return HttpResponse('i am personal')
def login(request):
        # 获取数据的两种方式
        # print(request.GET.get('id'))
        # print(request.GET['id'])
        # print(request)
        # 获得 json的数据 取得数据是字节
        # print(request.body)
        # json 的格式化
        # print(json.loads(request.body))
        # META 接受需要HTTP开头
        # print(request.META.get("HTTP_TOKEN"))
        # return HttpResponse('{"code":"001"}')


        #  等价于resp = HttpResponse('ok')
    if request.method == 'POST':
        mytoken = request.META.get('HTTP_TOKEN')
        print(mytoken)
        result = {
            "code": "成功"
        }
        resp = JsonResponse(result, status=200, charset="utf-8",
                                     content_type='application/json')
        date_int = datetime.utcnow()+timedelta(hours=1000)
        resp.set_cookie("token","1234567890",expires=date_int)
        resp['token'] = '8888888888888888888888888'
        resp['Access-Control-Expose-Headers'] = 'token'
        return resp
    else:
        return JsonResponse({"code":"404"})

def getuserbyid(request,id):
    return HttpResponse('i am getid '+id)
    # log_url=reverse('mylogin')
    # return redirect(log_url)