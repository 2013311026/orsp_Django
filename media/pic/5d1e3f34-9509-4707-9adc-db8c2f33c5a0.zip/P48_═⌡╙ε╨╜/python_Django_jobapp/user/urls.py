from django.conf.urls import url
from . import views
app_name='user'
#user 子路由
urlpatterns = [
    url(r'^$',views.personal,name='person'),
    url(r'login/', views.login,name='mylogin'),
    # ?P 取名<><myid>
    url(r'^getuser\w*/(?P<id>\d*)', views.getuserbyid,name='getuserbyid'),
]
