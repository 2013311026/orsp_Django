from django.apps import AppConfig


class BokeConfig(AppConfig):
    name = 'boke'
