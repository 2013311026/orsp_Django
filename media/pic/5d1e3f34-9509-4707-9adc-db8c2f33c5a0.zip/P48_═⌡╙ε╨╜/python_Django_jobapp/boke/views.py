from django.shortcuts import render
from django.http import  HttpResponse,response

# Create your views here.
def myboke(request):
    return HttpResponse('myboke')