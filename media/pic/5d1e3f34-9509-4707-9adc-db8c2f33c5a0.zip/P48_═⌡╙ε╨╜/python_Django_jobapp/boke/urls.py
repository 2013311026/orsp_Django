from django.conf.urls import url
from . import views
app_name='boke'
#user 子路由
urlpatterns = [
    url(r'^$',views.myboke,name='myboke'),

]
