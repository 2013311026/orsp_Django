from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import reverse,redirect
def index(request):
    # return HttpResponse('HELLO WORLD')
    # return render(request,'index.html')
    # reverse("模块名:路由名") 注意中间冒号,跨域重定向
    myurl =reverse('user:mylogin')
    # 调到 上述存的路由
    return redirect(myurl)


    # myurl = reverse('user:getuserbyid',kwargs={"id":188})
    # return redirect(myurl)